(function () {

    $('#imgUpldWrap').click(function (e) {
        return $('input:file').click();
    });

}).call(this);
<div class="sidebar" data-color="white" data-active-color="danger">
            <div class="logo">
                <a href="javascript:void(0)" class="simple-text logo-mini">
                    <div class="logo-image-small">
                        <img src="../assets/img/logo-small.png">
                    </div>
                </a>

                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li class="active ">
                        <a href="./dashboard.php">
                            <i class="nc-icon nc-layout-11"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li>
                        <a href="./creatList.php">
                            <i class="fa fa-file-text-o" aria-hidden="true"></i>
                            <p>Create List</p>
                        </a>
                    </li>
                    <li>
                        <a href="./list.php">
                            <i class="fa fa-file-text-o" aria-hidden="true"></i>
                            <p>List</p>
                        </a>
                    </li>
                    <li>
                        <a href="./headerSetting.php">
                            <i class="fa fa-header" aria-hidden="true"></i>
                            <p>Header Setting</p>
                        </a>
                    </li>
                    <li>
                        <a href="./imageSetting.php">
                            <i class="fa fa-picture-o" aria-hidden="true"></i>
                            <p>Image Setting</p>
                        </a>
                    </li>
                    <li>
                        <a href="./textSetting.php">
                            <i class="fa fa-file-text-o" aria-hidden="true"></i>
                            <p>Text Setting</p>
                        </a>
                    </li>


                </ul>
            </div>
        </div>

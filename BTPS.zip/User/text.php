<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="./assets/css/custom.css">
    <title>Document</title>

</head>

<body>
    <div class="mainbody">
        <div class="container-fluid headerColor">
            <div class="d-flex d-block justify-content-between">
                <h3>BTPS</h3>
                <h2 class="">Welcome Guest</h2>
                <div>
                </div>
            </div>
        </div>

        <div class="pr">
            <div class="imgWrap">
                <img src="./assets/img/hw3.jpg" alt="">
            </div>
            <div class="myText">
                   
            </div>
        </div>

    </div>
    <script src="./assets/js/bootstrap.bundle.min.js"></script>
</body>

</html>
<aside class="bgAside">
    <div class="asideProfile text-center">
        <div class="d-flex aic jcc py-3">
            <img src="http://localhost/BTPS/Admin/assets/img/profile.png" alt="Admin Image" class="asideImg">
        </div>
        <h6 class="mb-1">Admin</h6>
        <p>admin@btps.com</p>
    </div>
    div.
</aside>